﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Cartela
    {
        //Determinado o tamanho das cartelas para os dois jogadores
        private string[,] cartelaJogador1 = new string[5, 5];
        private string[,] cartelaJogador2 = new string[5, 5];
        private Random random = new Random();

        //Métodos que geram ambas as cartelas matrizes de 5 por 5 
        public void GerarCartelaJogador1()
        {
            GerarCartela(cartelaJogador1);
        }

        public void GerarCartelaJogador2()
        {
            GerarCartela(cartelaJogador2);
        }

        //Preenchendo as matrizes (cartelas) com a determinação de intervalos de numeros de 15 a 15 entre as colunas
        private void GerarCartela(string[,] cartela)
        {
            //Este é o primeiro intervalo de números a ser utilizado
            int menorNumero = 1;
            int maiorNumero = 15;

            for (int j = 0; j < 5; j++) 
            {
                int[] numeros = new int[5]; //Aqui é criado um vetor simbolizando cada coluna da cartela
                int indice = 0;

                while (indice < 5) //Enquanto o indice for menor que 5 ou seja 0 a 4 (5 colunas) preenchemos cada coluna das cartelas 
                {
                    int num = random.Next(menorNumero, maiorNumero + 1); //Números aleatórios gerados dentro do intervalo +1 garante que o maior número do intervalo não fique de fora

                    bool numeroSorteado = false; //Aqui garantimos que um número sorteado não apareça na cartela mais de uma vez
                    for (int k = 0; k < indice; k++)
                    {
                        if (numeros[k] == num)
                        {
                            numeroSorteado = true;
                        }
                    }

                    if (!numeroSorteado) //Se o número sorteado for diferente ele entra no vetor que simboliza a coluna
                    {
                        numeros[indice] = num;
                        indice++;
                    }
                }

                for (int i = 0; i < 5; i++) //Preenche cada coluna da cartela com os números que estão no vetor
                {
                    cartela[i, j] = numeros[i].ToString();
                }

                //Aqui o intervalo de números é aumentado para prosseguir as demais colunas da cartela
                menorNumero += 15;
                maiorNumero += 15;
            }

            cartela[2, 2] = "X"; //O meio da cartela 
        }
        //O processo se repete até que todas as 5 colunas da cada cartela estejam adequadamente construídas




        //Exibe as cartelas que foram preenchidas, e faz a marcação com * dos números que foram sortedaos
        public void ExibirCartelas(bool[,] marcados1, bool[,] marcados2)
        {
            Console.WriteLine();
            Console.WriteLine("Cartela Jogador 1   Cartela Jogador 2");
            Console.WriteLine("B  I  N  G  O       B  I  N  G  O");

            //Exibição da cartela do joagador 1
            for (int i = 0; i < 5; i++) 
            {
                for (int j = 0; j < 5; j++)
                {
                    string valor = cartelaJogador1[i, j];

                    if (valor == "X")
                    {
                        Console.Write(" X ");
                    }
                    else if (marcados1[i, j])
                    {
                        Console.Write($"{int.Parse(valor):D2}*"); //Se o número for sorteado ele vai receber um * em sua frente. Os números menores que 10 recebem 0 a esquerda
                    }
                    else
                    {
                        Console.Write($"{int.Parse(valor):D2} "); //Caso ele não tenha sido sorteado ainda vai aparecer normalmente
                    }
                }

                Console.Write("     "); // Espaço entre as cartelas

                //Exibição da cartela do jogador 2
                for (int j = 0; j < 5; j++)
                {
                    string valor = cartelaJogador2[i, j];

                    if (valor == "X")
                    {
                        Console.Write(" X ");
                    }
                    else if (marcados2[i, j])
                    {
                        Console.Write($"{int.Parse(valor):D2}*"); //A mesma visualização de sorteio acontece para o jogador 2
                    }
                    else
                    {
                        Console.Write($"{int.Parse(valor):D2} "); //Mesma visualização de sorteio aqui também
                    }
                }

                Console.WriteLine();
            }
        }

        //Gera novas cartelas para os dois jogadores, com intuito de uma nova partida
        public void Embaralhar()
        {
            GerarCartelaJogador1();
            GerarCartelaJogador2();
        }

        //Retornando a cartela do jogador 1 para poder ser utilizado em outras classes
        public string[,] GetCartelaJogador1()
        {
            return cartelaJogador1;
        }

        //O mesmo retorno é feito para o segundo jogador
        public string[,] GetCartelaJogador2()
        {
            return cartelaJogador2;
        }
    }
}
