﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Sorteio
    {
        private bool[] numerosSorteados = new bool[76]; // É determinado o maior valor que pode estar presente nas cartelas. No caso 75, 76 é utilizado para facilitar condições Ex: <76 ou seja até 75
        private Random random = new Random();

        //Armazenam quais posições ja foram marcadas para ambos os jogadores
        public bool[,] marcadosJogador1 = new bool[5, 5];
        public bool[,] marcadosJogador2 = new bool[5, 5];

        private Cartela cartela;

        public Sorteio(Cartela cartela)
        {
            this.cartela = cartela;

            // Para ambas as cartelas o centro ja é considerado como marcado
            marcadosJogador1[2, 2] = true;
            marcadosJogador2[2, 2] = true;

            // Considera que nenhum número foi sorteado ainda
            for (int i = 1; i <= 75; i++)
            {
                numerosSorteados[i] = false;
            }
        }

        // Aqui vamos sortear os numeros repetindo ate encontrar um que não foi sorteado
        public int SortearNumero()
        {
            int numero = 0;
            do
            {
                numero = random.Next(1, 76);
            } while (numerosSorteados[numero]);

            numerosSorteados[numero] = true; // Marca o número como ja sorteado

            MarcarCartelas(numero); // Utiliza o método para marcar o número em ambas as cartelas

            return numero;
        }

        private void MarcarCartelas(int numero)
        {
            // Utiliza as cartelas ja elaboradas para os jogadores para realizar a marcação dos números sorteados
            string[,] cartela1 = cartela.GetCartelaJogador1();
            string[,] cartela2 = cartela.GetCartelaJogador2();

            // Percorre a cartela do jogador 1 para realizar a marcação
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (cartela1[i, j] == numero.ToString())
                    {
                        marcadosJogador1[i, j] = true;
                    }
                }
            }

            // Percorre a cartela do jogador 2 para realizar a marcação
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (cartela2[i, j] == numero.ToString())
                    {
                        marcadosJogador2[i, j] = true;
                    }
                }
            }
        }
    }
}
