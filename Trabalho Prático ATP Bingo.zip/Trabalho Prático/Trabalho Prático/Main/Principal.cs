﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    internal class Principal
    {
        static void Main(string[] args)
        {
            Console.WriteLine("======== Seja bem-vindo ao bingo de ATP ========"); // Textos contextualizador do programa
            Console.WriteLine("            Vamos iniciar uma partida!");
            Console.WriteLine();
            Console.Write("Qual o seu nome Jogador 1? "); // Nome do 1º participante
            string nome1 = Console.ReadLine();

            Console.Write("Qual o seu nome Jogador 2? "); // Nome do 2º participante
            string nome2 = Console.ReadLine();

            // Objetos criados para consiliar com os métodos
            Cartela cartela = new Cartela();
            Bingo bingo = new Bingo();
            bool jogar = true; // Condição criada para que a partida ocorra até o usuário quiser parar

            //Nesta parte do código os métodos das demais classes entram em trabalho com suas respectivas funcionalidades, permitindo que cartelas sejam geradas preenchidas verificando se alguma condição de vitória            
            //ocorreu e por fim salvando e exibindo as pontuações dos jogadores que estão no arquivo
            while (jogar)
            {
                cartela.Embaralhar();

                Sorteio sorteio = new Sorteio(cartela);

                bool vitoria = false;

                while (!vitoria) // A partida ja iniciada continua até que alguma condição de vitória aconteça
                {
                    int numero = sorteio.SortearNumero(); // Sorteia um número
                    Console.WriteLine();
                    cartela.ExibirCartelas(sorteio.marcadosJogador1, sorteio.marcadosJogador2);
                    Console.WriteLine();
                    Console.WriteLine($"Número sorteado foi: {numero}"); // Mostra qual número sorteado

                    bingo.VerificarPontuacao(sorteio.marcadosJogador1, 1); // Verifica a pontuação do jogador 1
                    bingo.VerificarPontuacao(sorteio.marcadosJogador2, 2); // Verifica a pontuação do jogador 2

                    // Verifica todas as condições de vitória existentes, para ambos jogadores. Foi feito desta forma para evitar inúmeros else ifs. Fica mais organizado
                    if (bingo.VerificarLinha(sorteio.marcadosJogador1) ||
                        bingo.VerificarColuna(sorteio.marcadosJogador1) ||
                        bingo.VerificarDiagonal(sorteio.marcadosJogador1) ||
                        bingo.BingoCompleto(sorteio.marcadosJogador1) ||
                        bingo.VerificarLinha(sorteio.marcadosJogador2) ||
                        bingo.VerificarColuna(sorteio.marcadosJogador2) ||
                        bingo.VerificarDiagonal(sorteio.marcadosJogador2) ||
                        bingo.BingoCompleto(sorteio.marcadosJogador2))
                    {
                        vitoria = true;
                    }
                    Console.WriteLine();
                    Console.WriteLine("Aperte ENTER para sortear um novo número..."); // Forma utilizada para continuar com o jogo, sorteando novos números
                    Console.ReadLine();
                }

                // Exibe as pontuações dos dois jogadores e questiona se novas partidas serão jogadas
                Console.WriteLine($"Vamos aos resultados parciais! Quem está levando a melhor:");
                Console.WriteLine($"O jogador {nome1}: possui {bingo.nome1} pontos");
                Console.WriteLine($"O jogador {nome2}: possui {bingo.nome2} pontos");
                Console.WriteLine();
                Console.WriteLine("Que tal uma revanche?"); // Opção que param ou continuam o bingo
                Console.WriteLine("1 - Jogar novamente (gerar novas cartelas)");
                Console.WriteLine("2 - Deixe para uma próxima... (encerrar jogo)");

                string opcao = Console.ReadLine(); // Se digitar 1 novas cartelas irão ser geradas para novas partidas, se digitar 2 (a critério de exemplo) o jogo acaba
                if (opcao != "1")
                {
                    jogar = false;
                    Console.WriteLine();
                    Console.WriteLine("Fim de jogo.... Espero que tenha se divertido bastante!"); // Aqui o programa
                }
            }
        }
        
    }
    
}
