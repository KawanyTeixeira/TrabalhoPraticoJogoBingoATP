﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Bingo
    {
        // Pontuação inicial dos dois jogadores 
        public int nome1 = 0;
        public int nome2 = 0;

        // Informações de como o jogador ganhou
        public string vitoriaJogador1 = "";
        public string vitoriaJogador2 = "";

        // Observa se o jogador obteve alguma condição de vitória e determina suas respectivas pontuações 
        public void VerificarPontuacao(bool[,] marcados, int jogador)
        {
            bool ganhou = false;

            if (VerificarLinha(marcados)) // Atribui pontos por vitória por linha corresponde a 100 pontos
            {
                AdicionarPontos(jogador, 100);
                ganhou = true;
                RegistrarVitoria(jogador, "Linha");
            }

            if (VerificarColuna(marcados)) // Atribui pontos por vitória por coluna corresponde a 150 pontos
            {
                AdicionarPontos(jogador, 150);
                ganhou = true;
                RegistrarVitoria(jogador, "Coluna");
            }

            if (VerificarDiagonal(marcados)) // Atribui pontos por vitória por diagonal corresponde a 200 pontos 
            {
                AdicionarPontos(jogador, 200);
                ganhou = true;
                RegistrarVitoria(jogador, "Diagonal");
            }

            if (BingoCompleto(marcados)) // Atribui pontos por vencer com a cartela completa ganha 500 pontos
            {
                AdicionarPontos(jogador, 500);
                ganhou = true;
                RegistrarVitoria(jogador, "Cartela Cheia");
            }

            if (ganhou) // Permite pegar a pontuação e escreve-la no arquivo de pontuações
            {
                SalvarPontuacao();
            }
        }

        // Registra o tipo de vitória para o jogador
        private void RegistrarVitoria(int jogador, string tipoVitoria)
        {
            if (jogador == 1)
            {
                vitoriaJogador1 = tipoVitoria;
            }
            else if (jogador == 2)
            {
                vitoriaJogador2 = tipoVitoria;
            }
        }

        private void AdicionarPontos(int jogador, int pontos) // Se acontecer mais de uma partida e o mesmo jogador ganhar mais de uma vez, os pontos vão ser somados até que o jogo termine 
        {
            if (jogador == 1)
            {
                nome1 += pontos;
            }
            else if (jogador == 2)
            {
                nome2 += pontos;
            }
        }

        public bool VerificarLinha(bool[,] marcados) // Condição de vencer por linha, observa se alguma linha inteira foi marcada
        {
            for (int i = 0; i < 5; i++)
            {
                int quantidadeLinha = 0;
                for (int j = 0; j < 5; j++)
                {
                    if (marcados[i, j])
                    {
                        quantidadeLinha++;
                    }
                }
                if (quantidadeLinha == 5) // Se a quantidade de numeros marcadas em alguma linha for 5, vitória
                {
                    return true;
                }
            }
            return false;
        }

        public bool VerificarColuna(bool[,] marcados) // Condição de vencer com coluna, observa se alguma coluna inteira ja foi marcada 
        {
            for (int j = 0; j < 5; j++)
            {
                int quantidadeColuna = 0;
                for (int i = 0; i < 5; i++)
                {
                    if (marcados[i, j])
                    {
                        quantidadeColuna++;
                    }
                }
                if (quantidadeColuna == 5) // Se a quantidade de numeros marcadas em alguma coluna for 5, vitória
                {
                    return true;
                }
            }
            return false;
        }

        public bool VerificarDiagonal(bool[,] marcados) // Verifica se a diagonal principal ou secundária estão completamente marcadas
        {
            int principal = 0;
            int secundaria = 0;

            for (int i = 0; i < 5; i++)
            {
                if (marcados[i, i])
                {
                    principal++;
                }
                if (marcados[i, 4 - i])
                {
                    secundaria++;
                }
            }

            return principal == 5 || secundaria == 5; // Retorna true (vitória) se as 5 posições da diagonal principal ou secundária estiverem marcadas
        }

        public bool BingoCompleto(bool[,] marcados) // Observa se a cartela inteira foi completada 
        {
            int total = 0;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (marcados[i, j])
                    {
                        total++;
                    }
                }
            }
            return total == 25; // Se os 25 números da cartela estiverem marcados retorna como vitória
        }

        //Salva as pontuções dos jogadores ao decorrer de partidas. Esta pontuação será exibida e pode ser alterada se novas partidas forem jogadas, somando ao valor já existente
        private void SalvarPontuacao()
        {
            try
            {
                //true - se o usuário resolver jogar novamente, será salvo abaixo no arquivo, pois já vai existir.
                StreamWriter arqE = new StreamWriter("scores_bingo.txt", true, Encoding.UTF8);
                {
                    // Adicionando as informações de vitória e pontuação
                    arqE.WriteLine($"Jogador 1: {nome1} pontos; Vitória: {vitoriaJogador1}");
                    arqE.WriteLine($"Jogador 2: {nome2} pontos; Vitória: {vitoriaJogador2}");
                    arqE.WriteLine("---------------------------");
                }
                //Fechamento do arquivo após escrita.
                arqE.Close();
            }
            //Mensagem de erro caso algo dê errado
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            //Processo do try-catch finalizado 
            finally
            {
                Console.WriteLine("O try-catch foi finalizado...");
            }
        }
    }
}
